I WON'T ANSWER IF YOU DON'T PROVIDE SUCH DETAILS. COPY-PASTING IS NOT ENOUGH, I'M NOT A JEDI (YET).

Please provide those informations:

- [ ] Operating System (ie Ubuntu 16.04)
- [ ] Python version when running `gplaycli` (should be 3+)
- [ ] GPlayCli version via `gplaycli -v`
- [ ] The way you installed `gplaycli`: `git clone`, `git clone and setup.py`, `pip install gplaycli`, `apt install gplaycli`, ...
- [ ] The authentication method: (own) credentials or (own) token.
